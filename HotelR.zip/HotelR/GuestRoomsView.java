/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author safia
 */
public class GuestRoomsView extends JFrame implements ActionListener
{
    
    JTextField room_info = new JTextField(20);
   // JTextField checkout_date = new JTextField(20);

    int id =0;
    Date checkin_date, checkout_date;
    String strDate, endDate;
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton homePage = new JButton("Back to Home Page");

    JRadioButton[] radioBtn = new JRadioButton[20];

      String theSelectedRoom;
    Reservation checkAvailibility = new Reservation();
    ArrayList<Rooms> available_Rooms ;//= new ArrayList<>();
    
    // This constructor will create a panel that allows the user to input the clients details
    public GuestRoomsView() {
        
        try {
            // mainMenu = new MainMenu();
            this.setTitle("Available Rooms");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Room Details"));
            p2.setLayout(new GridLayout(4,2));
            //p2.add(new JLabel("Checkin date:", JLabel.LEFT));
   
            available_Rooms = checkAvailibility.getAvailableRooms();
           
            ButtonGroup group = new ButtonGroup();

            for (int i = 0; i < available_Rooms.size(); i++) {
                radioBtn[i] = new JRadioButton(available_Rooms.get(i).toString());

                    group.add((AbstractButton)p2.add(radioBtn[i]));
                    id = available_Rooms.get(i).getRoomID();
               
            } //for

            p3.setLayout(new FlowLayout());
            p3.add(homePage);
           // p3.add(cancel);
            homePage.addActionListener(this);
           // cancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
      
            for (int j = 0; j < available_Rooms.size(); j++){
        radioBtn[j].addActionListener(new ActionListener() {
            @Override
                public void actionPerformed(ActionEvent e) {
                    JRadioButton button = (JRadioButton)e.getSource();
                    System.out.println( button.getText() );
                    theSelectedRoom = button.getText();
                    
                }                                 
            });
        }

        } catch(Exception ex) {
            Logger.getLogger(RoomAvailibility.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public void actionPerformed(ActionEvent e)
        {

        JButton btn = (JButton) e.getSource();

        if (btn == homePage) {
            //check if the customer logged in or not?
            available_Rooms.clear();
            new Hotel();
     
        }//btn if 

        }

}


