/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author safia
 */
public class RoomAvailibility extends JFrame implements ActionListener{
    

    String[] roomString = { "1 Double Bed and 1 Twin Bed", "1 King bed", "2 Queen beds"};
    JComboBox room_type = new JComboBox(roomString);
    JTextField no_of_persons = new JTextField(20);
    JDateChooser checkin_datechooser = new JDateChooser();
    JDateChooser checkout_datechooser = new JDateChooser();
    JLabel dateLabel = new JLabel();
    Date checkin_date, checkout_date;
    String strDate, endDate;
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton check = new JButton("Check Availibility");
    JButton cancel = new JButton("Cancel");

    Reservation checkAvailibility = new Reservation();
    ArrayList<Rooms> available_Rooms ;
    
    // This constructor will create a panel that allows the user to input the clients details
    public RoomAvailibility() {
        
        try {
            available_Rooms = checkAvailibility.getAvailableRooms();
            this.setTitle("Check Availibility of Rooms");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Room Details"));
            p2.setLayout(new GridLayout(6,2));
            p2.add(new JLabel("Checkin date:", JLabel.LEFT));

            p2.add(checkin_datechooser);
            checkin_datechooser.addPropertyChangeListener("date", (PropertyChangeEvent e) -> {
                JDateChooser chooser=(JDateChooser)e.getSource();
                SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");
                strDate = (sdf.format(chooser.getDate()));
                checkin_date = (chooser.getDate());
            });
            
            p2.add(checkout_datechooser);
            checkout_datechooser.addPropertyChangeListener("date", (PropertyChangeEvent e) -> {
                JDateChooser chooser=(JDateChooser)e.getSource();
                SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-yyyy");
                endDate = (sdf.format(chooser.getDate()));
                checkout_date = chooser.getDate();
            });

            p2.add(new JLabel("Checkout date:", JLabel.LEFT));
            p2.add(new JLabel("Type of Room:", JLabel.LEFT));
            p2.add(room_type);
            p2.add(new JLabel("No of Persons:", JLabel.LEFT));
            p2.add(no_of_persons);
            
            p3.setLayout(new FlowLayout());
            p3.add(check);
            p3.add(cancel);
            check.addActionListener(this);
            cancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);

        } catch(Exception ex) {
            Logger.getLogger(RoomAvailibility.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // This method will clear all the fields
    public void clearFields() {

        no_of_persons.setText("");

    }  

    // This method checks that none of the fields are empty
    private boolean validation() {

        if (no_of_persons.getText().trim().length() == 0) {
            JOptionPane.showMessageDialog(this, "No of persons cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton btn = (JButton) e.getSource();

        boolean is = true;
        if (btn == check) {
            try{                
                if (validation() == true) {
                        checkAvailibility.checkAvailibility(room_type.getSelectedItem().toString(), 
                            strDate, endDate);
                        if(available_Rooms.isEmpty()==false){
                              new RoomsView();                         
                        }//if
                        else
                        {
                            JOptionPane.showConfirmDialog(this, "Room is not available!", "Message", JOptionPane.PLAIN_MESSAGE);
                            System.out.println(room_type.getSelectedItem().toString());
                            System.out.println(strDate);
                            System.out.println(checkin_date);                               
                        }
   
                     clearFields();
                    }   
                }catch (Exception ex) {
                    }//catch
        }//btn if 
        if (btn == cancel) {
            this.dispose();

        }
    }

}
