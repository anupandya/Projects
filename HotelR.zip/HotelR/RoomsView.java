/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;
import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
/**
 *
 * @author safia
 */
public class RoomsView extends JFrame implements ActionListener {


    int id =0;
    Date checkin_date, checkout_date;
    String strDate, endDate;
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton book = new JButton("Book");
    JButton cancel = new JButton("Cancel");

    JRadioButton[] radioBtn = new JRadioButton[20];
     ButtonGroup group = new ButtonGroup();

      String theSelectedRoom;
    Reservation checkAvailibility = new Reservation();
    ArrayList<Rooms> available_Rooms ;//= new ArrayList<>();
    // This constructor will create a panel that allows the user to input the clients details
    public RoomsView() {

            this.setTitle("Available Rooms");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Room Details"));
            p2.setLayout(new GridLayout(4,2));

            available_Rooms = checkAvailibility.getAvailableRooms();
            System.out.println(available_Rooms.size());

            for (int i = 0; i < available_Rooms.size(); i++) {
                radioBtn[i] = new JRadioButton(available_Rooms.get(i).print());

                    group.add((AbstractButton)p2.add(radioBtn[i]));
                    id = available_Rooms.get(i).getRoomID();
                 
            } //for

            p3.setLayout(new FlowLayout());
            p3.add(book);
            p3.add(cancel);
            book.addActionListener(this);
            cancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
      
            for (int j = 0; j < available_Rooms.size(); j++){
                radioBtn[j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JRadioButton button = (JRadioButton)e.getSource();
                        System.out.println( button.getText() );
                        theSelectedRoom = button.getText();
                    
                }                                 
            });
        }
        }
    
   public void actionPerformed(ActionEvent e)
        {

        JButton btn = (JButton) e.getSource();
        if (btn == book) {
            new FinalBookRoom(id);

        }//btn if 
        if (btn == cancel) {
            this.dispose();

        }

        }


  
}

