/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.util.Date;

/**
 *
 * @author safia
 */
public class Rooms {
 
    
    private int room_id;
    private String room_type;
    private Date available_start_date;
    private Date available_end_date;
    private double roomRatePerDay;
    boolean isBooked = true; 

    public Rooms(int room_id, String room_type, Date available_start_date, Date available_end_date,
            double dailyRate, boolean isBooked) {

        this.room_id = room_id;
        this.room_type = room_type;
        this.available_start_date = available_start_date;
        this.available_end_date = available_end_date;
        this.roomRatePerDay = dailyRate;
        this.isBooked = isBooked;
}

    public int getRoomID() {

        return room_id;

    }

    public void setRoomID(int roomID) {

        this.room_id = roomID;

    }

    public String getRoomType() {

        return room_type;

    }

    public void setRoomType(String roomType) {

        this.room_type = roomType;

    }

    public Date getStartDate() {

        return available_start_date;

    }

    public void setStartDate(Date startDate) {

        this.available_start_date = startDate;

    }

    public Date getEndDate() {

        return available_end_date;

    }

    public void setEndDate(Date endDate) {

        this.available_end_date = endDate;

    }
    
    public double getDailyRate() {

        return roomRatePerDay;

    }

    public void setDailyRate(double dailyRate) {

        this.roomRatePerDay = dailyRate;

    }
    public boolean getIsBooked() {

        return isBooked;

    }

    public void setIsBooked(boolean isBooked) {

        this.isBooked = isBooked;

    }
    @Override

    public String toString() {

        return room_id + " " + room_type + " \n" + "Start Date: " + available_start_date + "End Date: "
            + available_end_date+ ", " + "\n Daily Rate: " + roomRatePerDay;

    }

    public String print() {

        return this.toString();

    }

}
