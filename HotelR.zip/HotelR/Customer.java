/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Swetha
 */
public class Customer extends JFrame
{
protected String firstName;
protected String lastName;  
int phoneNumber;
int custID;
protected String custUsername, custPwd;
boolean isLogged=false;

public Customer(String firstName, String lastName, String custUsername, String custPwd, boolean isLogged)
   {   
        this.firstName = firstName;
        this.lastName = lastName;
        this.custUsername=custUsername;
        this.custPwd=custPwd;
        this.isLogged=false;

    }

public String getFirstName() 
{

return firstName;

}

public void setFirstName(String fName)
{
    this.firstName = fName;
    
}

public String getLastName() 
{

return lastName;

}

public void setLastName(String lName)
{
    this.lastName=lName;
    
}

public String getUserName()
{
    return custUsername;
}

public void setUserName(String cUname)
{
    this.custUsername = cUname;
}

public String getPwd()
{
    return custPwd;
}

public void setPwd(String cPwd)
{
    this.custPwd = cPwd;
}

public boolean getFlag()
{
    return isLogged;
}

public void setFlag(boolean isLog)
{
    this.isLogged=isLog;
}
public String toString() 
{
        return "Customer [First Name=" + firstName
                + ", Last Name=" + lastName 
                + ", User Name=" + custUsername
                + ", Password=" + custPwd + "]";
    }

}
