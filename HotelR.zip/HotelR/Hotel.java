/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Swetha
 */
public class Hotel extends JFrame implements ActionListener
{

    
    String fName, lName, uName, cPwd;
    boolean isLog = false;  
 
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton btnLogin = new JButton("Login");
    JButton btnSignUp = new JButton("SignUp");
    JButton btnCheckRoomAvailability = new JButton("Check Availability");
    
// Constructor to create the Hotel window 
    public Hotel()
    {
            this.setTitle("Welcome");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Welcome to Dream Hotels!"));
            p2.setLayout(new GridLayout(6,2));
            
            ImageIcon image = new ImageIcon(getClass().getResource("hotel.png"));
            JLabel lblImage = new JLabel(image);
            p2.add(lblImage);
            
            p2.add(new JLabel("2340 NW, 23rd Street, Florida", JLabel.CENTER));
            p2.add(new JLabel("1-800-599-6676", JLabel.CENTER));
            p2.add(new JLabel("Book online or call", JLabel.CENTER));
                       
            p3.setLayout(new FlowLayout());
            p3.add(btnLogin);
            p3.add(btnSignUp);
            p3.add(btnCheckRoomAvailability);
            btnLogin.addActionListener(this);
            btnSignUp.addActionListener(this);
            btnCheckRoomAvailability.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
         
    }
    
    // action Performed methods for SignUp, Login buttons 
    @Override
    public void actionPerformed(ActionEvent ae) 
    {
        JButton btn = (JButton) ae.getSource();
        if(btn== btnSignUp)
        {
            SignUp signup= new SignUp();
        }
        if(btn==btnLogin)
        {
            Login login = new Login();
        }
        if(btn==btnCheckRoomAvailability)
        {
            new GuestCheckAvailability();
        }             
           
    }

    public static void main(String[] args)
    {
        new Hotel();
    }
}

