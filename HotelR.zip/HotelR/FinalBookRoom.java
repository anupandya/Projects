/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author safia
 */
public class FinalBookRoom extends JFrame implements ActionListener {

    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton ptp = new JButton("Proceed to Payment");
    JButton cancel = new JButton("Cancel");
    Reservation checkA = new Reservation();
    ArrayList<Rooms> available_Rooms ;
    long diffInMillies, diff;
    Date checkin, checkout;
    String roomType;
    double dailyRate;
    double price;
    
    // This constructor will create a panel that allows the user to input the clients details
    public FinalBookRoom(int theSelectedRoom) {
        
        try {

            available_Rooms = checkA.getAvailableRooms();
            this.setTitle("Booking Confirmation Details");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Room Details"));
            p2.setLayout(new GridLayout(6,2));
         
            p2.add(new JLabel("Your Room Description: ", JLabel.LEFT));
           int i =0;
           checkin =available_Rooms.get(i).getStartDate();
           checkout =available_Rooms.get(i).getEndDate();
           roomType = available_Rooms.get(i).getRoomType();
           dailyRate = available_Rooms.get(i).getDailyRate();

            if(theSelectedRoom == available_Rooms.get(i).getRoomID());
            {
                p2.add(new JLabel("Checkin Date: "+checkin.toString()));
                p2.add(new JLabel("Checkout Date: "+available_Rooms.get(i).getEndDate().toString()));
                p2.add(new JLabel("Room Type: "+roomType));
                diffInMillies = Math.abs(available_Rooms.get(i).getEndDate().getTime()
                        - available_Rooms.get(i).getStartDate().getTime());
                diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                price = dailyRate * diff;
                p2.add(new JLabel("Price: "+ price));
                System.out.println(dailyRate);
            }
         
            p3.setLayout(new FlowLayout());
            p3.add(ptp);
            p3.add(cancel);
            ptp.addActionListener(this);
            cancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);

        } catch(Exception ex) {
            Logger.getLogger(RoomAvailibility.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton btn = (JButton) e.getSource();

        boolean is = true;
        if (btn == ptp) {
               new Payment(checkin, checkout, roomType, price, diff);
        
                    }   

        if (btn == cancel) {
            this.dispose();
        }

    }
}

