/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Swetha
 */
public class CustomerWelcome extends JFrame implements ActionListener
{
        boolean isLoggedin ;
        String name;
               
            JPanel p1 = new JPanel();
            JPanel p2 = new JPanel();
            JPanel p3 = new JPanel();            
            JButton btnCheckAvailability = new JButton("Check Availability");
            JButton btnSignOut = new JButton("SignOut");
            
    
    public CustomerWelcome(){
        this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            
            this.setTitle("Welcome");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Welcome to Dream Hotels! "));

            p2.setLayout(new GridLayout(6,2));
            
            p3.setLayout(new FlowLayout());
            p3.add(btnCheckAvailability);
            p3.add(btnSignOut);
            
            btnCheckAvailability.addActionListener(this);
            btnSignOut.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
        }
    
    public CustomerWelcome(String userName, boolean isActive)
    {
        this.name=userName;
        this.isLoggedin=isActive;
        
        this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            
            this.setTitle("Dream Hotels");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Welcome to Dream Hotels, "+ name + "!"));

            p2.setLayout(new GridLayout(6,2));
            
            p3.setLayout(new FlowLayout());
            p3.add(btnCheckAvailability);
            p3.add(btnSignOut);

            btnCheckAvailability.addActionListener(this);
            btnSignOut.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
       
    }

        @Override 
        public void actionPerformed(ActionEvent e) 
    {
        JButton btn = (JButton) e.getSource();

        if (btn == btnCheckAvailability) 
        {

        RoomAvailibility checkRooms = new RoomAvailibility();
        this.dispose();
        }
        
        if(btn==btnSignOut)
        {        
        isLoggedin = false ;
        JOptionPane.showConfirmDialog(this, "You have been signed out!", "Message", JOptionPane.PLAIN_MESSAGE);
        this.dispose();
        
        }                
    }
   
}

