/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author safia
 */
public class Payment extends JFrame implements ActionListener {

    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton confirm = new JButton("Confirm Booking");
    JButton cancel = new JButton("Cancel");
    Reservation checkAvailibility = new Reservation();
    ArrayList<Rooms> available_Rooms ;
    
    // This constructor will create a panel that allows the user to input the clients details
    public Payment(Date checkin, Date checkout, String roomType, double price, double days) 
    {
            available_Rooms = checkAvailibility.getAvailableRooms();
            this.setTitle("Secure Booking");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Great choice! Don't wait, book now!"));
            p2.setLayout(new GridLayout(6,2));
            p2.add(new JLabel("1 Room: Comfort           "));
            p2.add(new JLabel( days+ "-night stay"));
            p2.add(new JLabel("Total Price"));
            p2.add(new JLabel(" "+price));
            p2.add(new JLabel("Cardholder Name: "));
            p2.add(new JTextField(20));
            p2.add(new JLabel("Debit/Credit card number: "));
            p2.add(new JTextField(20));
            p2.add(new JLabel("Expiration code: "));
            p2.add(new JTextField(20));                
            p2.add(new JLabel("Security code: "));
            p2.add(new JTextField(20));

            p3.setLayout(new FlowLayout());
            p3.add(confirm);
            p3.add(cancel);
            confirm.addActionListener(this);
            cancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);

        
    }



    @Override
    public void actionPerformed(ActionEvent e) {
        JButton btn = (JButton) e.getSource();

        boolean is = true;
        if (btn == confirm) {
            JOptionPane.showConfirmDialog(this, "Thank you for booking at Dream Hotels!", "Message", JOptionPane.PLAIN_MESSAGE);
            new CustomerWelcome();
        }
        if (btn == cancel) {
            this.dispose();
            new Hotel();
        }

    }

}

