/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


/**
 *
 * @author Swetha
 */
public class Login extends JFrame implements ActionListener
{
    public static boolean isLoggedin;
    JTextField uName = new JTextField(20);
    JPasswordField cPwd = new JPasswordField(20);
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    JButton btnLogin = new JButton("Login");
    JButton btnCancel = new JButton("Cancel");
 // This constructor will create a panel that allows the user to input the clients details
    ArrayList<Customer> UserList;
    AddList al = new AddList();
    public String custUserName, custPwd;

    /**
     *
     */
    public Login() 
    {
            UserList = al.getListNew();
        
            this.setTitle("Dream Hotels - Log In!");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Enter Login Information"));
           p2.setLayout(new GridLayout(6,2));

            p2.add(new JLabel("Username", JLabel.LEFT));
            p2.add(uName);
            
            p2.add(new JLabel("Password", JLabel.LEFT));
            p2.add(cPwd);            
            
            p3.setLayout(new FlowLayout());
            p3.add(btnLogin);
            p3.add(btnCancel);
            btnLogin.addActionListener(this);
            btnCancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
            
            
      
    }
    
    
// This method will clear all the fields

    /**
     *
     */
    
    
    public void clearFields() 
    {
      
        uName.setText("");
        cPwd.setText("");
    }
    
    

    public String getCustUserName() 
    {
        return custUserName;
    }
   
    public boolean getIsLogFlag()
    {
        
        return isLoggedin;
    }
    

     // This method checks that none of the fields are empty
    private boolean validation() 
    {
        

        if (uName.getText().trim().length() == 0) {
            JOptionPane.showMessageDialog(this, "Username cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (cPwd.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        
        return true;
    }
    
    public boolean loginUser(String uName, String cPwd)
    {
        System.out.println(UserList.size());
          
          for(Customer list :UserList)
        {
            if(list.getUserName().equals(uName))
            {
                if(list.getPwd().equals(cPwd))
            {
                             return true;
                
            }

            }
            return false;
        }
            
            
                 
        return false;
        

        
    }
    
    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        JButton btn = (JButton) e.getSource();

        if (btn == btnLogin) 
        {               
                if (validation() == true)
                { 
                    custUserName =uName.getText();
                    custPwd=String.valueOf(cPwd.getPassword());
                    boolean y = loginUser(custUserName, custPwd);
                    {
                        if(y == true)
                            {
                                JOptionPane.showConfirmDialog(this, "Login Successful!", "Message", JOptionPane.PLAIN_MESSAGE);
                                isLoggedin = true;
                                CustomerWelcome cwin = new CustomerWelcome(custUserName,true);
                                this.dispose();
                            }
                        
                        
                        else
                        {
                           JOptionPane.showMessageDialog(this, "Enter Valid Credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                           clearFields();

                        }
                    }
                }
                
        else {                    
                JOptionPane.showConfirmDialog(this, "Login Unsuccessful!", "Error", JOptionPane.ERROR_MESSAGE);
                isLoggedin = false; 
                  clearFields(); 
            }
        
        //this.dispose();
        }
        
        //btn if 
        if (btn == btnCancel) 
       {
            this.dispose();
        }
    }

    /**
     *
     * @param args
     */
    public static void main(String args[]) {
        new Login();
    }

    
}

