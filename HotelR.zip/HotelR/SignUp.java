/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


/**
 *
 * @author Swetha
 */
public class SignUp extends JFrame implements ActionListener
{
    String firstName, lastName, uName,uPwd ,cPwd;

    //Creating TTextFields for user input
    JTextField f_name = new JTextField(20);
    JTextField l_name = new JTextField(20);
    JTextField userName = new JTextField(20);
    JPasswordField pswd = new JPasswordField(20);
    JPasswordField confirmPswd = new JPasswordField(20);

    //Creating JPanels 
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    JPanel p3 = new JPanel();
    
    //Adding Buttons Sign Up and Cancel to the JPanel
    JButton btnSignUp = new JButton("Sign Up");
    JButton btnCancel = new JButton("Cancel");
    ArrayList<Customer> listNew ;//= new ArrayList<>();
    Customer cAdd;
    AddList add_list = new AddList();


  // This constructor will create a panel that allows the user to input the his/her details
    public SignUp() 
    {
            listNew = add_list.getListNew();
            this.setTitle("Dream Hotels - Sign Up!");
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setLayout(new BorderLayout());
            this.setVisible(true);
            this.setSize(500,300);
            p1.setLayout(new FlowLayout());
            p1.add(new JLabel("Create Your Account"));
            p2.setLayout(new GridLayout(6,2));
            p2.add(new JLabel("First Name", JLabel.LEFT));
            p2.add(f_name);
           
            p2.add(new JLabel("Last Name", JLabel.LEFT));
            p2.add(l_name);

            p2.add(new JLabel("Username", JLabel.LEFT));
            p2.add(userName);
            
            p2.add(new JLabel("Password", JLabel.LEFT));
            p2.add(pswd);            
            p2.add(new JLabel("Confirm Password", JLabel.LEFT));
            p2.add(confirmPswd);
            
            p3.setLayout(new FlowLayout());
            p3.add(btnSignUp);
            p3.add(btnCancel);
            btnSignUp.addActionListener(this);
            btnCancel.addActionListener(this);
            this.add(p1, BorderLayout.NORTH);
            this.add(p2, BorderLayout.CENTER);
            this.add(p3, BorderLayout.SOUTH);
                
         }


    // Method to clear all fields
    public void clearFields() 
    {
        f_name.setText("");
        l_name.setText("");
        userName.setText("");
        pswd.setText("");
        confirmPswd.setText("");
    }  
    
    // SignUp Method which checks if the username already exists before signing up
    //@return boolean - checking if the entered username exists or not
     public boolean SignUp(String fName, String lName, String uName, String cPwd)
    {
         for(Customer list : listNew)
             
        {
            if(list.getUserName().equals(uName))
            {

                return false;
            }
           
        }

        return true;
        
    }

    
    
    // This method checks that none of the fields are empty
    private boolean validation() 
    {
                  
        if (f_name.getText().trim().length() == 0) 
        {
            JOptionPane.showMessageDialog(this, "First name cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
       
        if (l_name.getText().trim().length() == 0) 
        {
            JOptionPane.showMessageDialog(this, "Last name cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        

        if (userName.getText().trim().length() == 0) 
        {
            JOptionPane.showMessageDialog(this, "Username cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
       
        if (pswd.getPassword().length == 0) 
        {
            JOptionPane.showMessageDialog(this, "Password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (confirmPswd.getPassword().length== 0) 
        {

            JOptionPane.showMessageDialog(this, "Password cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
       
       
        return true;
    }
    
    //Method to add the new user after successful sign up 
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        JButton btn = (JButton) e.getSource();

        if (btn == btnSignUp) 
            
        {       
            if (validation() == true)   
                {
                  firstName=f_name.getText().toString();
                  lastName=l_name.getText().trim();
                  uName=userName.getText().trim();
                  uPwd=String.valueOf(pswd.getPassword());
                  cPwd=String.valueOf(confirmPswd.getPassword());
                  System.out.println("Current size" + listNew.size()); 
                       if(uPwd.equals(cPwd)) 
                          {
                                
                                 boolean x = SignUp(firstName, lastName, uName, uPwd);
                                 if (x== true)
                                    {   
                                        listNew.add(new Customer(firstName,lastName,uName,uPwd,false));
                                        JOptionPane.showConfirmDialog(this, "Sign Up Successful!", "Message", JOptionPane.PLAIN_MESSAGE);
                                     
                                       System.out.println(listNew);
                                       this.dispose();
                                     }
                                else
                                      {
                        
                                        JOptionPane.showMessageDialog(this, "Username Exists!", "Error", JOptionPane.ERROR_MESSAGE);
                                        clearFields();
                                       }
                          }                   
                       else
                          {
                   
                          JOptionPane.showMessageDialog(this, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                            clearFields();

                          }                                    
                  }
               
       }
                    
                   
        // Cancel button
        if (btn == btnCancel) 
        {
            this.dispose();
        }
}

    public static void main(String args[]) 
    {
        new SignUp();
       
        
        }

    }


    

