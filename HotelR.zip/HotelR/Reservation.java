/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelR;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author safia
 */
public class Reservation {
    

    Rooms[] roomList= new Rooms[5];
    private static ArrayList<Rooms> availableRooms = new ArrayList<>();
    SimpleDateFormat fmt = new SimpleDateFormat("MM-dd-yyy");
   
    public Reservation(){

    try{   
       
        Date s_date = fmt.parse("04-04-2018");
        Date e_date = fmt.parse("04-06-2018");
        
        Date s = fmt.parse("04-11-2018");
        Date e = fmt.parse("04-14-2018");
        
        Rooms room1 = new Rooms(21, "1 King bed", s_date, e_date,50.0, true);
        roomList[0] = room1;
        Rooms room2 = new Rooms(22, "2 Queen beds", s_date, e_date,40.0, true);
        roomList[1] = room2;
        Rooms room3 = new Rooms(23, "1 Double Bed and 1 Twin Bed", s_date, e_date,30.0, false);
        roomList[2] = room3;
        Rooms room4 = new Rooms(24, "1 King bed", s_date, e_date, 60.0, false);
        roomList[3] = room4;
        Rooms room5 = new Rooms(25, "1 King bed", s_date, e_date,20.0, true);
        roomList[4] = room5;
        
    }catch(Exception e){
        
        }//catch
    
    }//endFunc

    public static ArrayList<Rooms> getAvailableRooms() {
        return availableRooms;
    }

    /**
     * 
     * @param room_type
     * @param available_start_date
     * @param available_end_date
     * @return true or false
     */
    public void checkAvailibility(String room_type, String available_start_date, 
        String available_end_date) throws ParseException{
        
        Date start_date = fmt.parse(available_start_date);
          Date end_date = fmt.parse(available_end_date);

        for (Rooms roomList1 : roomList) {
           // System.out.println("In the loop " + roomList1.getRoomID());
            if (roomList1.getIsBooked() == true) {
                if (room_type == roomList1.getRoomType()) {
                    if (start_date.after(roomList1.getStartDate()) || start_date.equals(roomList1.getStartDate())) {
                        if (end_date.before(roomList1.getEndDate()) || end_date.equals(roomList1.getEndDate())) {
                            availableRooms.add(roomList1);

                        }
                    }
                }
                //return roomList[i];
            } //if
            // return true;
        } //for
        //   return false;    
    }//func

}//class
